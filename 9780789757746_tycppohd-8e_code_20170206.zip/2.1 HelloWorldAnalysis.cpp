// Pre-processor directive
#include <iostream>

// Start of your program
int main()
{
   /* Write to the screen using std::cout */
   std::cout << "Hello World" << std::endl;

   // Return a value to the OS
   return 0;
}