#include <iostream>
int main()
{
    std::cout << "Hello Buggy World \n";
    return 0;
}
